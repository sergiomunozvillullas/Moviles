package com.example.m02_sergio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {
    private Button btn_enviar;
    private TextView id_editTextText2;
    private TextView id_editTextText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia), MODE_PRIVATE);


        String myName = pref.getString("myName","stranger");
        String myColor = pref.getString("myColor","0");

        Log.d("Preferencias", "Nombre: " + myName + ", Color: " + myColor);


        btn_enviar = findViewById(R.id.btn_enviar);
        id_editTextText2 = findViewById(R.id.id_editTextText2);
        id_editTextText = findViewById(R.id.id_editTextText);

    }
    public void saveMyName(View view) {
        Intent i = new Intent(WelcomeActivity.this, MainActivity.class);

        SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia), MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("myName", id_editTextText2.getText().toString());
        editor.putString("myColor", id_editTextText.getText().toString());
        editor.apply();
        startActivity(i);
        finish();
    }



}
