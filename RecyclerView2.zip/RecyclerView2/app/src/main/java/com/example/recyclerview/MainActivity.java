package com.example.recyclerview;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private MyAdapter adapter;
    private List<Actividad> listaActividades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaActividades = new ArrayList<>();
        adapter = new MyAdapter(listaActividades);
        recyclerView.setAdapter(adapter);

        // Botón para agregar una nueva actividad al RecyclerView
        Button buttonNuevaActividad = findViewById(R.id.button_nuevaactividad);
        buttonNuevaActividad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                solicitarNuevaActividad(); // Método para pedir el nombre de la nueva actividad al usuario
            }
        });

        // Inicializar el RecyclerView con algunas actividades
        inicializarActividades();
    }

    private void solicitarNuevaActividad() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Nueva Actividad");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nuevoNombreActividad = input.getText().toString();
                if (!nuevoNombreActividad.isEmpty()) {
                    // Agregar una nueva actividad a la lista con el nombre ingresado por el usuario
                    Actividad nuevaActividad = new Actividad(nuevoNombreActividad);
                    listaActividades.add(nuevaActividad);

                    // Notificar al adaptador que se ha agregado un nuevo elemento
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "Por favor, ingresa un nombre para la actividad", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void inicializarActividades() {
        listaActividades.add(new Actividad("Hacer los deberes"));
        listaActividades.add(new Actividad("Ir al gimnasio"));
        listaActividades.add(new Actividad("Lavar los platos"));
    }
}
