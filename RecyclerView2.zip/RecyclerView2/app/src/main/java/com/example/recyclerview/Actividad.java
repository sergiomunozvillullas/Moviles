package com.example.recyclerview;


//la clase actividad es un objeto que contiene actividad como string, es decir, el nombre de la actividad
//y un boolean completada que nos dira en true si está hecha la actvidad o no
public class Actividad {
    private String tarea;
    private boolean completada;

    public Actividad(String tarea) {
        this.tarea = tarea;
        this.completada = false;
    }

    public String getTarea() {
        return tarea;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }

}
