package com.example.recyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;


//esta clase extiende el RecyclerView que contendrá el item checkBox del layout para marcar la actividad
//y el text view que es el string
//luego tiene un metodo que contiene su atributo que es un array de actividad llamado myDataset
//

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<Actividad> listaActividades;

    public MyAdapter(List<Actividad> listaActividades) {
        this.listaActividades = listaActividades;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Actividad actividad = listaActividades.get(position);
        holder.tareaTextView.setText(actividad.getTarea());
        holder.checkBoxCompletada.setChecked(actividad.isCompletada());

        // Manejar el cambio de estado de la actividad al marcar/desmarcar la casilla de verificación
        holder.checkBoxCompletada.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Si se marca el CheckBox, quitar la actividad de la lista
                listaActividades.remove(actividad);
                notifyDataSetChanged(); // Actualizar el RecyclerView
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaActividades.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView tareaTextView;
        public CheckBox checkBoxCompletada;

        public MyViewHolder(View view) {
            super(view);
            tareaTextView = view.findViewById(R.id.textView);
            checkBoxCompletada = view.findViewById(R.id.checkBox);
        }
    }
}

