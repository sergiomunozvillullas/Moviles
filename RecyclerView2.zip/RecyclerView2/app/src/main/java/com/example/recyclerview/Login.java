package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText editTextUsername, editTextPassword;
    Button buttonLogin;
    Button buttonRegistrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegistrar = findViewById(R.id.buttonRegistrar);

        SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia),MODE_PRIVATE);

        String myName = pref.getString("myName","");
        String myPwd = pref.getString("myPwd","");


        buttonLogin.setOnClickListener(v -> {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();


            if (username.equals(myName) && password.equals(myPwd)) {
                // Autenticación exitosa, iniciar la siguiente actividad
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);
            } else {
                // Mensaje de error o acción en caso de credenciales incorrectas
                Toast.makeText(Login.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
            }
        });

        //de esta forma no tienes que crear un onclick y ponerselo
        buttonRegistrar.setOnClickListener(v -> {

                // Autenticación exitosa, iniciar la siguiente actividad
                Intent i = new Intent(Login.this, Registrar.class);
                startActivity(i);

        });


    }
}
