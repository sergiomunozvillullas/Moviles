package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Registrar extends AppCompatActivity {
        private Button botoncrear;
        private TextView nombre;
        private TextView contraseña;

       protected void onCreate(Bundle savedInstanceState){
           super.onCreate(savedInstanceState);
       setContentView((R.layout.activity_registrar));
           SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia),MODE_PRIVATE);

            String myName = pref.getString("myName","");
            String myPwd = pref.getString("myPwd","");

            botoncrear = findViewById(R.id.buttonLogin2);
           nombre = findViewById(R.id.editTextUsername2);
           contraseña = findViewById(R.id.editTextPassword2);


       }

       public void savedMyName(View view){
           Intent i = new Intent(Registrar.this, Login.class);
           startActivity(i);
           SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia),MODE_PRIVATE);
           SharedPreferences.Editor editor = pref.edit();
           editor.putString("myName", nombre.getText().toString());
           editor.putString("myPwd", contraseña.getText().toString());
           editor.apply();
       }


    }
