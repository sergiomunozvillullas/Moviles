package com.example.m02_sergio;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WelcomeActivity extends AppCompatActivity {
    private Button btn_enviar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome); // Asegúrate de que coincida con el layout de WelcomeActivity
        Log.i("Welcome", "Información");
        Log.w("Welcome", "Advertencia");
        btn_enviar2 = findViewById(R.id.btn_enviar2);

        Bundle extras = getIntent().getExtras();
        String saludo = extras.getString("saludo");
        String nombre = extras.getString("nombre");
        SimpleDateFormat fechaActual = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy 'a las' HH:mm:ss 'GMT'", Locale.getDefault());
        Date fecha = new Date(System.currentTimeMillis());
        fechaActual.format(fecha);
       // Toast.makeText(WelcomeActivity.this, "Ha iniciado sesión: "+nombre, Toast.LENGTH_LONG).show();
       // Toast.makeText(WelcomeActivity.this, saludo, Toast.LENGTH_LONG).show();
        //Toast.makeText(WelcomeActivity.this, "Sesión iniciada el " + fecha, Toast.LENGTH_LONG).show();

        btn_enviar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(WelcomeActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}
