package com.example.m02_sergio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btn_enviar;
    private Button btn_enviar3;
    private Button btn_enviar4;
    private TextView textView_pref;

    private TextView id_editTextText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia), MainActivity.MODE_PRIVATE);
        String myName = pref.getString("myName","stranger");
        textView_pref = findViewById(R.id.textView3);
        textView_pref.setText("Hola "+myName);

        Log.i("Main", "Información");
        Log.w("Main", "Advertencia");

        btn_enviar = findViewById(R.id.btn_enviar);
        id_editTextText2 = findViewById(R.id.id_editTextText2);


    }
    public void saveMyName(View view) {
        Intent i = new Intent(MainActivity.this, WelcomeActivity.class);

        SharedPreferences pref = getSharedPreferences(getString(R.string.label_preferencia), MainActivity.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("myName", id_editTextText2.getText().toString());
        editor.apply();
        startActivity(i);
        finish();
    }

}
